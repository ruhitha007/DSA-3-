const BASE_URL = "http://localhost:8080";

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

/**
 * Checks the backend health endpoint.
 * Returns true when the backend reports "running".
 */
export async function checkHealth() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(`${BASE_URL}/api/health`, {
      signal: controller.signal,
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data && data.status === "running";
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Sends the selected PDF as raw binary data to the
 * backend analysis endpoint (matches the Java contract).
 */
export async function analyzePdf(file) {
  const controller = new AbortController();
  // Analysis (search + download + DSA) can take a while.
  const timer = setTimeout(() => controller.abort(), 240000);

  try {
    const res = await fetch(`${BASE_URL}/api/analyze`, {
      method: "POST",
      headers: {
        "Content-Type": "application/pdf",
      },
      body: file,
      signal: controller.signal,
    });

    let data = null;
    const text = await res.text().catch(() => "");

    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
        data = null;
      }
    }

    if (!res.ok) {
      const msg =
        data && data.message
          ? data.message
          : `Backend responded with status ${res.status}`;
      throw new ApiError(msg, res.status);
    }

    if (!data || typeof data !== "object") {
      throw new ApiError("Unexpected response from backend.", 0);
    }

    if (data.status === "error") {
      throw new ApiError(
        data.message || "Analysis failed. Please try again.",
        0
      );
    }

    return data;
  } catch (err) {
    if (err && err.name === "AbortError") {
      throw new ApiError(
        "The analysis took too long. Please try again.",
        0
      );
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}