import { formatNumber, formatDecimal } from "../utils/format";
import styles from "./DSAChart.module.css";

function BarGroup({ label, kmpValue, rkValue, format }) {
  const max = Math.max(kmpValue, rkValue, 1);
  const kmpH = Math.max(4, Math.round((kmpValue / max) * 100));
  const rkH = Math.max(4, Math.round((rkValue / max) * 100));

  return (
    <div className={styles.group}>
      <p className={styles.groupLabel}>{label}</p>
      <div className={styles.bars}>
        <div className={styles.barColumn}>
          <span className={styles.barValue}>
            {format(kmpValue)}
          </span>
          <div
            className={`${styles.bar} ${styles.kmp}`}
            style={{ height: `${kmpH}%` }}
          />
          <span className={styles.barName}>KMP</span>
        </div>
        <div className={styles.barColumn}>
          <span className={styles.barValue}>
            {format(rkValue)}
          </span>
          <div
            className={`${styles.bar} ${styles.rk}`}
            style={{ height: `${rkH}%` }}
          />
          <span className={styles.barName}>Rabin-Karp</span>
        </div>
      </div>
    </div>
  );
}

/**
 * Pure-CSS bar chart comparing execution time and
 * character comparisons. No chart library dependency.
 */
export default function DSAChart({ dsa }) {
  const kmp = dsa.kmp || {};
  const rk = dsa.rabinKarp || {};

  const kmpTime = Number(kmp.executionTimeMs ?? 0);
  const rkTime = Number(rk.executionTimeMs ?? 0);
  const kmpChars = Number(kmp.characterComparisons ?? 0);
  const rkChars = Number(rk.characterComparisons ?? 0);

  return (
    <div className={styles.card}>
      <div className={styles.legend}>
        <span className={styles.legendItem}>
          <span className={`${styles.legendDot} ${styles.kmp}`} />
          KMP
        </span>
        <span className={styles.legendItem}>
          <span className={`${styles.legendDot} ${styles.rk}`} />
          Rabin-Karp
        </span>
      </div>

      <div className={styles.chart}>
        <BarGroup
          label="Execution Time (ms)"
          kmpValue={kmpTime}
          rkValue={rkTime}
          format={(v) => `${formatDecimal(v)} ms`}
        />
        <BarGroup
          label="Character Comparisons"
          kmpValue={kmpChars}
          rkValue={rkChars}
          format={(v) => formatNumber(v)}
        />
      </div>
    </div>
  );
}