import { formatNumber, formatDecimal } from "../utils/format";
import DSAChart from "./DSAChart";
import styles from "./DSAComparison.module.css";

export default function DSAComparison({ dsa }) {
  if (!dsa) return null;

  const kmp = dsa.kmp || {};
  const rk = dsa.rabinKarp || {};

  return (
    <section className={`fade-in ${styles.section}`}>
      <div className="section-head">
        <h2>DSA Algorithm Comparison</h2>
        <span className="rule" />
      </div>

      <div className={styles.grid}>
        <div className={styles.algCard}>
          <div className={`${styles.algHeader} ${styles.kmp}`}>
            <span className={styles.swatch} aria-hidden="true" />
            <h3>KMP</h3>
          </div>
          <dl className={styles.stats}>
            <div className={styles.stat}>
              <dt>Matches Found</dt>
              <dd>{formatNumber(kmp.matchesFound)}</dd>
            </div>
            <div className={styles.stat}>
              <dt>Character Comparisons</dt>
              <dd>{formatNumber(kmp.characterComparisons)}</dd>
            </div>
            <div className={styles.stat}>
              <dt>Execution Time</dt>
              <dd>{formatDecimal(kmp.executionTimeMs)} ms</dd>
            </div>
          </dl>
        </div>

        <div className={styles.algCard}>
          <div className={`${styles.algHeader} ${styles.rk}`}>
            <span className={styles.swatch} aria-hidden="true" />
            <h3>Rabin-Karp</h3>
          </div>
          <dl className={styles.stats}>
            <div className={styles.stat}>
              <dt>Matches Found</dt>
              <dd>{formatNumber(rk.matchesFound)}</dd>
            </div>
            <div className={styles.stat}>
              <dt>Hash Comparisons</dt>
              <dd>{formatNumber(rk.hashComparisons)}</dd>
            </div>
            <div className={styles.stat}>
              <dt>Character Comparisons</dt>
              <dd>{formatNumber(rk.characterComparisons)}</dd>
            </div>
            <div className={styles.stat}>
              <dt>Execution Time</dt>
              <dd>{formatDecimal(rk.executionTimeMs)} ms</dd>
            </div>
          </dl>
        </div>
      </div>

      {dsa.observation && (
        <div className={styles.observation}>
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            aria-hidden="true"
          >
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <span>{dsa.observation}</span>
        </div>
      )}

      <DSAChart dsa={dsa} />
    </section>
  );
}