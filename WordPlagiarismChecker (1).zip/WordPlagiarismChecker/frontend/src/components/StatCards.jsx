import { formatNumber, formatDecimal } from "../utils/format";
import styles from "./StatCards.module.css";

function Card({ label, value, sub, icon }) {
  return (
    <div className={styles.card}>
      <div className={styles.icon} aria-hidden="true">
        {icon}
      </div>
      <p className={styles.label}>{label}</p>
      <p className={styles.value}>{value}</p>
      {sub && <p className={styles.sub}>{sub}</p>}
    </div>
  );
}

export default function StatCards({ result }) {
  const plagiarism = result.plagiarism || {};
  const ref = result.referencePaper;
  const refCount = (result.referencePapers || []).length;

  return (
    <section className={`fade-in ${styles.section}`}>
      <div className="section-head">
        <h2>Statistics</h2>
        <span className="rule" />
      </div>
      <div className={styles.grid}>
        <Card
          label="Total Words"
          value={formatNumber(plagiarism.totalWords)}
          sub="words analysed"
          icon={
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2Z" />
              <path d="M8 7h7M8 11h7M8 15h4" />
            </svg>
          }
        />
        <Card
          label="Matched Words"
          value={formatNumber(plagiarism.matchedWords)}
          sub="found in reference"
          icon={
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M20 6 9 17l-5-5" />
            </svg>
          }
        />
        <Card
          label="Highest Similarity"
          value={`${formatDecimal(plagiarism.similarity)}%`}
          sub={
            refCount > 1
              ? `highest of ${refCount} references`
              : "overall match"
          }
          icon={
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="9" />
              <circle cx="12" cy="12" r="5.5" />
              <circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none" />
            </svg>
          }
        />
        <Card
          label="Reference Papers"
          value={
            refCount > 0 ? `${refCount} Selected` : "Fallback"
          }
          sub={
            refCount > 0
              ? ref && ref.year
                ? `best match ${ref.year}`
                : "external papers"
              : "local document"
          }
          icon={
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
            </svg>
          }
        />
      </div>
    </section>
  );
}