import { useMemo, useState } from "react";
import { formatNumber, formatDecimal } from "../utils/format";
import styles from "./MatchTable.module.css";

const PAGE_SIZE = 12;

export default function MatchTable({ matches, subtitle }) {
  const [query, setQuery] = useState("");
  const [visible, setVisible] = useState(PAGE_SIZE);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return matches;
    return matches.filter((m) => {
      const textMatch = (m.matchedText || "").toLowerCase().includes(q);
      const userMatch = String(m.userPosition ?? "").includes(q);
      const sourceMatch = String(m.sourcePosition ?? "").includes(q);
      return textMatch || userMatch || sourceMatch;
    });
  }, [matches, query]);

  const shown = filtered.slice(0, visible);

  function handleQuery(value) {
    setQuery(value);
    setVisible(PAGE_SIZE);
  }

  if (!matches || matches.length === 0) {
    return (
<section className={`fade-in ${styles.section}`}>
      <div className="section-head">
        <h2>Matched Text</h2>
        <span className="rule" />
      </div>
      {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
      <div className={styles.empty}>
        No matching passages were found.
      </div>
    </section>
    );
  }

  return (
    <section className={`fade-in ${styles.section}`}>
      <div className="section-head">
        <h2>Matched Text</h2>
        <span className="rule" />
        <span className="chip">
          {formatNumber(matches.length)} matching passages found
        </span>
      </div>
      {subtitle && <p className={styles.subtitle}>{subtitle}</p>}

      <div className={styles.card}>
        <div className={styles.toolbar}>
          <div className={styles.searchWrap}>
            <svg
              width="17"
              height="17"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              aria-hidden="true"
            >
              <circle cx="11" cy="11" r="7" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input
              type="search"
              value={query}
              onChange={(e) => handleQuery(e.target.value)}
              placeholder="Filter matches..."
              aria-label="Filter matches"
            />
          </div>
          <span className={styles.count}>
            Showing {formatNumber(shown.length)} of{" "}
            {formatNumber(filtered.length)}
          </span>
        </div>

        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Matched Text</th>
                <th>User Position</th>
                <th>Source Position</th>
                <th>Match %</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((m, idx) => (
                <tr key={`${m.matchedText}-${m.userPosition}-${idx}`}>
                  <td className={styles.textCell}>“{m.matchedText}”</td>
                  <td className={styles.numCell}>
                    {formatNumber(m.userPosition)}
                  </td>
                  <td className={styles.numCell}>
                    {formatNumber(m.sourcePosition)}
                  </td>
                  <td>
                    <span className={styles.matchPill}>
                      {formatDecimal(m.similarity)}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {shown.length < filtered.length && (
          <div className={styles.more}>
            <button
              type="button"
              className="btn-ghost"
              onClick={() => setVisible((v) => v + PAGE_SIZE)}
            >
              Show more
            </button>
          </div>
        )}

        {shown.length === 0 && (
          <p className={styles.noResults}>
            No matches match your filter.
          </p>
        )}
      </div>
    </section>
  );
}