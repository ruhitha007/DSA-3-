import styles from "./AnalysisButton.module.css";

export default function AnalysisButton({ onClick, disabled, loading }) {
  return (
    <button
      type="button"
      className={`btn-primary ${styles.button}`}
      onClick={onClick}
      disabled={disabled || loading}
    >
      {loading && (
        <span className={styles.spinner} aria-hidden="true" />
      )}
      <span>{loading ? "Analyzing…" : "Analyze Document"}</span>
    </button>
  );
}