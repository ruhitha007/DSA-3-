import styles from "./LoadingState.module.css";

const STAGES = [
  "Extracting document",
  "Finding reference paper",
  "Running plagiarism analysis",
  "Comparing DSA algorithms",
  "Preparing results",
];

export default function LoadingState({ currentStage }) {
  const currentIndex = STAGES.indexOf(currentStage);

  return (
    <div className={styles.card}>
      <div className={styles.row}>
        <div className={styles.spinner} aria-hidden="true" />
        <div>
          <p className={styles.heading}>Analyzing document...</p>
          <p className={styles.current}>{currentStage}</p>
        </div>
      </div>

      <ul className={styles.stages}>
        {STAGES.map((stage, i) => {
          let state = styles.pending;
          if (i < currentIndex) state = styles.done;
          if (i === currentIndex) state = styles.active;
          return (
            <li key={stage} className={state}>
              <span className={styles.bullet} aria-hidden="true">
                {i < currentIndex ? (
                  <svg
                    width="12"
                    height="12"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                ) : (
                  i + 1
                )}
              </span>
              <span>{stage}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}