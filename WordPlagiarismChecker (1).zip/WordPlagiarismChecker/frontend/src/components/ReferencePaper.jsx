import { formatNumber, formatDecimal } from "../utils/format";
import styles from "./ReferencePaper.module.css";

function PaperCard({ index, entry }) {
  const paper = entry.referencePaper || {};
  const kmp = entry.kmp;
  const rk = entry.rabinKarp;

  return (
    <div className={styles.card}>
      <div className={styles.rank} aria-hidden="true">
        {index}
      </div>

      <div className={styles.body}>
        <p className={styles.title}>
          {paper.title || "Untitled paper"}
        </p>

        <p className={styles.authors}>
          {paper.authors && paper.authors.length > 0
            ? paper.authors.join(", ")
            : "Authors not listed"}
        </p>

        <div className={styles.meta}>
          {paper.year && (
            <span className="chip">Published {paper.year}</span>
          )}
          <span className={styles.paperId}>
            {paper.paperId || "paper id unavailable"}
          </span>
        </div>

        <div className={styles.stats}>
          <div className={styles.stat}>
            <span className={styles.statLabel}>Similarity</span>
            <b>{formatDecimal(entry.similarity)}%</b>
          </div>
          <div className={styles.stat}>
            <span className={styles.statLabel}>Matched Words</span>
            <b>{formatNumber(entry.matchedWords)}</b>
          </div>
          <div className={styles.stat}>
            <span className={styles.statLabel}>KMP Matches</span>
            <b>{kmp ? formatNumber(kmp.matchesFound) : "—"}</b>
          </div>
          <div className={styles.stat}>
            <span className={styles.statLabel}>Rabin-Karp Matches</span>
            <b>{rk ? formatNumber(rk.matchesFound) : "—"}</b>
          </div>
        </div>
      </div>

      <div className={styles.actions}>
        {paper.url && (
          <a
            className={styles.linkBtn}
            href={paper.url}
            target="_blank"
            rel="noreferrer"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
              <path d="M15 3h6v6" />
              <path d="M10 14 21 3" />
            </svg>
            View on Semantic Scholar
          </a>
        )}
        {paper.openAccessPdf && (
          <a
            className={styles.pdfBtn}
            href={paper.openAccessPdf}
            target="_blank"
            rel="noreferrer"
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="M14 3v4a1 1 0 0 0 1 1h4" />
              <path d="M17 21H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z" />
            </svg>
            Open PDF
          </a>
        )}
      </div>
    </div>
  );
}

export default function ReferencePaper({ paper, message, references }) {
  const isFallback =
    typeof message === "string" && message.includes("fallback");

  const list =
    references && references.length > 0 ? references : [];

  if (list.length === 0) {
    return (
      <section className={`fade-in ${styles.section}`}>
        <div className="section-head">
          <h2>Reference Paper</h2>
          <span className="rule" />
        </div>

        <div className={styles.unavailable}>
          <div className={styles.icon} aria-hidden="true">
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
            </svg>
          </div>
          <p className={styles.unavailableTitle}>
            Reference paper metadata unavailable
          </p>
          {isFallback && (
            <p className={styles.note}>
              Reference analysis used the local fallback document.
            </p>
          )}
        </div>
      </section>
    );
  }

  return (
    <section className={`fade-in ${styles.section}`}>
      <div className="section-head">
        <h2>Reference Papers</h2>
        <span className="rule" />
        <span className="chip">
          {list.length} external reference
          {list.length > 1 ? "s" : ""} analyzed
        </span>
      </div>

      <div className={styles.stack}>
        {list.map((entry, i) => {
          const paper = entry.referencePaper || {};
          return (
            <PaperCard
              key={paper.paperId || i}
              index={i + 1}
              entry={entry}
            />
          );
        })}
      </div>
    </section>
  );
}