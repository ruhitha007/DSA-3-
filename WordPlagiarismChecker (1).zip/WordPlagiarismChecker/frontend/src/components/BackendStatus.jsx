import styles from "./BackendStatus.module.css";

export default function BackendStatus({ status }) {
  const label =
    status === "online"
      ? "Backend Connected"
      : status === "offline"
      ? "Backend Offline"
      : "Checking backend…";

  const dotClass =
    status === "online"
      ? styles.online
      : status === "offline"
      ? styles.offline
      : styles.checking;

  return (
    <div className={styles.pill} aria-live="polite">
      <span className={`${styles.dot} ${dotClass}`} aria-hidden="true" />
      <span>{label}</span>
    </div>
  );
}