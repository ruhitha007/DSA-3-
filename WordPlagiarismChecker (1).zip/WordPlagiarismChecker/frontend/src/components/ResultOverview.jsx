import { formatNumber, formatDecimal } from "../utils/format";
import styles from "./ResultOverview.module.css";

const RADIUS = 82;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

function severity(score) {
  if (score < 15)
    return { label: "Low", cls: styles.low };
  if (score < 40)
    return { label: "Moderate", cls: styles.moderate };
  return { label: "High", cls: styles.high };
}

export default function ResultOverview({ result }) {
  const plagiarism = result.plagiarism || {};
  const similarity = Number(plagiarism.similarity ?? 0);
  const matched = Number(plagiarism.matchedWords ?? 0);
  const total = Number(plagiarism.totalWords ?? 0);
  const clamped = Math.max(0, Math.min(100, similarity));
  const offset = CIRCUMFERENCE - (clamped / 100) * CIRCUMFERENCE;
  const sev = severity(clamped);
  const refCount = (result.referencePapers || []).length;

  return (
    <section className={`fade-in ${styles.section}`}>
      <div className={styles.overview}>
        <div className={styles.ring}>
          <svg width="210" height="210" viewBox="0 0 210 210">
            <circle
              cx="105"
              cy="105"
              r={RADIUS}
              fill="none"
              stroke="var(--powder)"
              strokeWidth="14"
            />
            <circle
              cx="105"
              cy="105"
              r={RADIUS}
              fill="none"
              stroke="var(--navy)"
              strokeWidth="14"
              strokeLinecap="round"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={offset}
              transform="rotate(-90 105 105)"
              style={{ transition: "stroke-dashoffset 0.8s ease" }}
            />
          </svg>
          <div className={styles.ringCenter}>
            <p className={styles.scoreLabel}>
              {refCount > 1 ? "HIGHEST REFERENCE SIMILARITY" : "PLAGIARISM SCORE"}
            </p>
            <p className={styles.scoreValue}>{formatDecimal(similarity)}%</p>
            <span className={`${styles.severity} ${sev.cls}`}>
              {sev.label}
            </span>
          </div>
        </div>

        <div className={styles.summary}>
          <h2 className={styles.summaryTitle}>Analysis Summary</h2>
          <p className={styles.summaryText}>
            {refCount > 1
              ? `This document was compared against ${refCount} external reference papers. The score shown is the highest similarity found across all references.`
              : "This document was compared against an external reference paper using the plagiarism engine and the KMP / Rabin-Karp DSA comparison."}
          </p>
          <div className={styles.summaryRow}>
            <div>
              <p className={styles.summaryValue}>{formatNumber(matched)}</p>
              <p className={styles.summaryLabel}>Matched Words</p>
            </div>
            <div>
              <p className={styles.summaryValue}>{formatNumber(total)}</p>
              <p className={styles.summaryLabel}>Total Words</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}