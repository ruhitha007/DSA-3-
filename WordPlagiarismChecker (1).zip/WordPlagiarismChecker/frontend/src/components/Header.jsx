import styles from "./Header.module.css";

export default function Header() {
  return (
    <header className={styles.header}>
      <div className="container">
        <div className={styles.inner}>
          <div className={styles.brand}>
            <span className={styles.mark} aria-hidden="true">
              <svg
                width="30"
                height="30"
                viewBox="0 0 32 32"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="32" height="32" rx="9" fill="#B5D2E6" opacity="0.25" />
                <path
                  d="M6 13c2.4-3.4 4.8-3.4 7.2 0s4.8 3.4 7.2 0 4.8-3.4 7.2 0"
                  stroke="#FFF1E7"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
                <path
                  d="M6 19.4c2.4-3.4 4.8-3.4 7.2 0s4.8 3.4 7.2 0 4.8-3.4 7.2 0"
                  stroke="#B5D2E6"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
                <path
                  d="M6 25.8c2.4-3.4 4.8-3.4 7.2 0"
                  stroke="#805232"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
              </svg>
            </span>
            <div className={styles.brandText}>
              <h1 className={styles.brandName}>PlagiaSense</h1>
              <p className={styles.brandSub}>
                DSA-Powered Academic Plagiarism Detection
              </p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}