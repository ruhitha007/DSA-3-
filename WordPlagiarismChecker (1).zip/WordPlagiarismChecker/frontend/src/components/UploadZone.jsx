import { useRef, useState } from "react";
import { formatBytes, isPdfFile } from "../utils/format";
import styles from "./UploadZone.module.css";

export default function UploadZone({ file, onFile, onClear, disabled }) {
  const inputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);
  const [rejected, setRejected] = useState("");

  function acceptFile(candidate) {
    if (!candidate) return;
    if (isPdfFile(candidate)) {
      setRejected("");
      onFile(candidate);
    } else {
      setRejected("Please upload a valid PDF.");
    }
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragActive(false);
    if (disabled) return;
    acceptFile(e.dataTransfer.files && e.dataTransfer.files[0]);
  }

  function handleChange(e) {
    acceptFile(e.target.files && e.target.files[0]);
  }

  return (
    <div className={styles.wrapper}>
      <div
        className={`${styles.dropzone} ${dragActive ? styles.active : ""} ${
          file ? styles.hasFile : ""
        } ${disabled ? styles.disabled : ""}`}
        onClick={() => !disabled && inputRef.current && inputRef.current.click()}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDragActive(true);
        }}
        onDragLeave={() => setDragActive(false)}
        onDrop={handleDrop}
        role="button"
        aria-label="Upload a PDF document"
      >
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf,.pdf"
          onChange={handleChange}
          hidden
        />

        {!file ? (
          <div className={styles.placeholder}>
            <div className={styles.uploadIcon} aria-hidden="true">
              <svg
                width="34"
                height="34"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M12 16V4" />
                <path d="m7 9 5-5 5 5" />
                <path d="M4 17v2a1.5 1.5 0 0 0 1.5 1.5h13A1.5 1.5 0 0 0 20 19v-2" />
              </svg>
            </div>
            <p className={styles.title}>Drag &amp; drop your PDF here</p>
            <p className={styles.subtitle}>or browse files from your computer</p>
            <span className={styles.browse}>Browse files</span>
          </div>
        ) : (
          <div className={styles.selected}>
            <div className={styles.fileBadge} aria-hidden="true">
              <svg
                width="34"
                height="34"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.7"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <rect x="4" y="2.5" width="16" height="19" rx="2.5" />
                <path d="M8.5 7h7M8.5 11.5h7M8.5 16h4" />
              </svg>
            </div>
            <div className={styles.fileInfo}>
              <p className={styles.fileName}>{file.name}</p>
              <p className={styles.fileMeta}>
                PDF • {formatBytes(file.size)}
              </p>
            </div>
            <button
              type="button"
              className={styles.removeBtn}
              onClick={(e) => {
                e.stopPropagation();
                if (inputRef.current) inputRef.current.value = "";
                onClear();
              }}
              aria-label="Remove selected file"
            >
              <svg
                width="20"
                height="20"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              >
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}
      </div>

      {rejected && <p className={styles.rejected}>{rejected}</p>}
    </div>
  );
}