import { useCallback, useEffect, useRef, useState } from "react";
import Header from "./components/Header";
import BackendStatus from "./components/BackendStatus";
import UploadZone from "./components/UploadZone";
import AnalysisButton from "./components/AnalysisButton";
import LoadingState from "./components/LoadingState";
import ResultOverview from "./components/ResultOverview";
import StatCards from "./components/StatCards";
import MatchTable from "./components/MatchTable";
import DSAComparison from "./components/DSAComparison";
import ReferencePaper from "./components/ReferencePaper";
import { checkHealth, analyzePdf } from "./services/api";
import styles from "./App.module.css";

const STAGES = [
  "Extracting document",
  "Finding reference paper",
  "Running plagiarism analysis",
  "Comparing DSA algorithms",
  "Preparing results",
];

function friendlyError(err) {
  if (!err) return "Analysis failed. Please try again.";

  if (err && err.name === "AbortError") {
    return "The analysis took too long. Please try again.";
  }

  if (err instanceof TypeError) {
    // fetch network failure
    return "Unable to connect to plagiarism backend.";
  }

  if (err && err.name === "ApiError") {
    if (err.status === 404 || err.status === 0) return "Analysis failed. Please try again.";
    return "Analysis failed. Please try again.";
  }

  return "Analysis failed. Please try again.";
}

export default function App() {
  const [backendStatus, setBackendStatus] = useState("checking");
  const [file, setFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [stageIndex, setStageIndex] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const stageTimer = useRef(null);

  const checkBackend = useCallback(async () => {
    setBackendStatus("checking");
    const ok = await checkHealth();
    setBackendStatus(ok ? "online" : "offline");
  }, []);

  useEffect(() => {
    checkBackend();
  }, [checkBackend]);

  function clearStageTimer() {
    if (stageTimer.current) {
      clearInterval(stageTimer.current);
      stageTimer.current = null;
    }
  }

  async function handleAnalyze() {
    if (!file) {
      setError("Please upload a valid PDF.");
      return;
    }

    setError("");
    setResult(null);
    setAnalyzing(true);
    setStageIndex(0);

    clearStageTimer();
    stageTimer.current = setInterval(() => {
      setStageIndex((i) => Math.min(i + 1, STAGES.length - 1));
    }, 1800);

    try {
      const data = await analyzePdf(file);
      setResult(data);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setError(friendlyError(err));
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally {
      clearStageTimer();
      setAnalyzing(false);
    }
  }

  function handleReset() {
    setFile(null);
    setResult(null);
    setError("");
    setAnalyzing(false);
    clearStageTimer();
    setStageIndex(0);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <div className={styles.app}>
      <Header />

      <main className="container">
        <section className={styles.hero}>
          <div className={styles.heroTop}>
            <div>
              <h1 className={styles.heroTitle}>Upload your research paper</h1>
              <p className={styles.heroSub}>
                Drag &amp; drop a PDF below to check it against external
                reference papers discovered automatically.
              </p>
            </div>
            <BackendStatus status={backendStatus} />
          </div>

          <UploadZone
            file={file}
            onFile={setFile}
            onClear={() => setFile(null)}
            disabled={analyzing}
          />

          <div className={styles.analyzeRow}>
            <AnalysisButton
              onClick={handleAnalyze}
              loading={analyzing}
              disabled={!file}
            />
          </div>
        </section>

        {error && (
          <div className="error-banner" role="alert">
            <svg
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              aria-hidden="true"
              style={{ flex: "none", marginTop: 1 }}
            >
              <circle cx="12" cy="12" r="9" />
              <path d="M12 8v4M12 16h.01" />
            </svg>
            <span className="message">{error}</span>
            {backendStatus === "offline" && (
              <button type="button" className="btn-ghost" onClick={checkBackend}>
                Retry connection
              </button>
            )}
          </div>
        )}

        {analyzing && (
          <LoadingState currentStage={STAGES[stageIndex]} />
        )}

        {result && !analyzing && (
          <div className={styles.results}>
            <ResultOverview result={result} />
            <StatCards result={result} />
            <MatchTable
              matches={result.matches || []}
              subtitle={
                (result.referencePapers || []).length > 0
                  ? "Matched Text — Highest Similarity Reference"
                  : undefined
              }
            />
            <DSAComparison dsa={result.dsaComparison} />
            <ReferencePaper
              paper={result.referencePaper}
              message={result.message}
              references={result.referencePapers || []}
            />

            <div className={styles.again}>
              <p className={styles.againText}>Want to check another paper?</p>
              <button type="button" className="btn-primary" onClick={handleReset}>
                Analyze Another PDF
              </button>
            </div>
          </div>
        )}
      </main>

      <footer className="site-footer">
        <div className="container">
          PlagiaSense — DSA-powered academic plagiarism detection · Marina
          design language
        </div>
      </footer>
    </div>
  );
}