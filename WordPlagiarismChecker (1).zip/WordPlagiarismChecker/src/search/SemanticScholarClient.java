package search;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class SemanticScholarClient {

    public static List<JsonObject> searchPapers(
            String query) throws Exception {

        List<JsonObject> results =
                new ArrayList<>();

        String apiKey =
                System.getenv("SEMANTIC_SCHOLAR_API_KEY");

        if (apiKey == null || apiKey.isBlank()) {

            System.out.println(
                    "Semantic Scholar API key not found."
            );

            return results;
        }

        String encodedQuery =
                URLEncoder.encode(
                        query,
                        StandardCharsets.UTF_8
                );

        String apiUrl =
                "https://api.semanticscholar.org/graph/v1/paper/search"
                + "?query=" + encodedQuery
                + "&limit=20"
                + "&fields=paperId,title,authors,year,url,openAccessPdf";

        String responseBody =
                queryWithRetry(apiUrl, apiKey);

        if (responseBody == null
                || responseBody.isBlank()) {

            return results;
        }

        Gson gson = new Gson();

        JsonObject root =
                gson.fromJson(
                        responseBody,
                        JsonObject.class
                );

        if (!root.has("data")) {
            return results;
        }

        JsonArray papers =
                root.getAsJsonArray("data");

        for (int i = 0;
             i < papers.size();
             i++) {

            JsonObject paper =
                    papers.get(i)
                            .getAsJsonObject();

            results.add(paper);
        }

        return results;
    }


    /*
     * Performs the search request with a single retry
     * for HTTP 429 rate limits. Network or API failures
     * degrade gracefully by returning null, which the
     * caller treats as an empty candidate list.
     */
    private static String queryWithRetry(
            String apiUrl,
            String apiKey) throws Exception {

        int maxAttempts = 2;

        for (int attempt = 1;
             attempt <= maxAttempts;
             attempt++) {

            HttpURLConnection connection = null;

            try {

                URI uri = URI.create(apiUrl);

                URL url = uri.toURL();

                connection =
                        (HttpURLConnection)
                                url.openConnection();

                connection.setRequestMethod("GET");

                connection.setRequestProperty(
                        "Accept",
                        "application/json"
                );

                connection.setRequestProperty(
                        "x-api-key",
                        apiKey
                );

                int responseCode =
                        connection.getResponseCode();

                if (responseCode == 429) {

                    System.out.println(
                            "Semantic Scholar rate limit reached."
                    );

                    if (attempt < maxAttempts) {

                        System.out.println(
                                "Retrying request once..."
                        );

                        Thread.sleep(1000);

                        continue;
                    }

                    System.out.println(
                            "Semantic Scholar retry also "
                                    + "rate limited."
                    );

                    return null;
                }

                if (responseCode != 200) {

                    System.out.println(
                            "Semantic Scholar API error: "
                                    + responseCode
                    );

                    return null;
                }

                BufferedReader reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getInputStream(),
                                        StandardCharsets.UTF_8
                                )
                        );

                StringBuilder response =
                        new StringBuilder();

                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();

                return response.toString();

            } catch (IOException e) {

                System.out.println(
                        "Semantic Scholar request failed: "
                                + e.getMessage()
                );

                return null;

            } finally {

                if (connection != null) {
                    connection.disconnect();
                }
            }
        }

        return null;
    }


    /*
     * Finds the first paper in the search results
     * that has an open-access PDF available.
     *
     * Returns the paper metadata as a JsonObject,
     * or null when no paper has a usable PDF.
     */
    public static JsonObject findPaperWithOpenAccessPdf(
            String query) throws Exception {

        List<JsonObject> papers =
                searchPapers(query);

        for (JsonObject paper : papers) {

            if (paper.has("openAccessPdf")
                    && !paper.get("openAccessPdf")
                            .isJsonNull()) {

                JsonObject pdf =
                        paper.getAsJsonObject(
                                "openAccessPdf"
                        );

                if (pdf.has("url")
                        && !pdf.get("url").isJsonNull()
                        && !pdf.get("url")
                                .getAsString()
                                .isBlank()) {

                    return paper;
                }
            }
        }

        return null;
    }


    /*
     * Returns the open-access PDF URL of the first
     * paper that has one, or null.
     */
    public static String findFirstOpenAccessPdf(
            String query) throws Exception {

        JsonObject paper =
                findPaperWithOpenAccessPdf(query);

        if (paper == null) {
            return null;
        }

        return paper.getAsJsonObject("openAccessPdf")
                .get("url")
                .getAsString();
    }
}