package search;

public class TestSemanticScholar {

    public static void main(String[] args) {

        try {

            String pdfUrl =
                    SemanticScholarClient
                            .findFirstOpenAccessPdf(
                                    "machine learning in Python"
                            );

            if (pdfUrl != null) {

                System.out.println(
                        "\nFINAL PDF URL:"
                );

                System.out.println(pdfUrl);

            } else {

                System.out.println(
                        "\nNo PDF was found."
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}