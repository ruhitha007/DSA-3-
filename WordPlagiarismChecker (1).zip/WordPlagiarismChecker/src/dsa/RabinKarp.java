package dsa;

public class RabinKarp {

    private static final int BASE = 256;
    private static final int PRIME = 101;

    /**
     * Searches for a pattern inside a text using
     * the Rabin-Karp string matching algorithm.
     *
     * This is the original search method used
     * by the project.
     *
     * @param text    the text to search in
     * @param pattern the pattern to find
     * @return starting index of the first match, or -1
     */
    public static int search(String text, String pattern) {

        if (text == null || pattern == null) {
            return -1;
        }

        if (pattern.length() == 0) {
            return 0;
        }

        if (pattern.length() > text.length()) {
            return -1;
        }

        int patternLength = pattern.length();
        int textLength = text.length();

        long patternHash = 0;
        long textHash = 0;

        long highestPower = 1;

        // Calculate BASE^(patternLength - 1)
        for (int i = 0;
             i < patternLength - 1;
             i++) {

            highestPower =
                    (highestPower * BASE) % PRIME;
        }

        // Calculate initial hash values
        for (int i = 0;
             i < patternLength;
             i++) {

            patternHash =
                    (BASE * patternHash
                            + pattern.charAt(i))
                            % PRIME;

            textHash =
                    (BASE * textHash
                            + text.charAt(i))
                            % PRIME;
        }

        // Slide the pattern across the text
        for (int i = 0;
             i <= textLength - patternLength;
             i++) {

            // If hashes match, verify characters
            if (patternHash == textHash) {

                boolean match = true;

                for (int j = 0;
                     j < patternLength;
                     j++) {

                    if (text.charAt(i + j)
                            != pattern.charAt(j)) {

                        match = false;
                        break;
                    }
                }

                if (match) {
                    return i;
                }
            }

            // Calculate hash for the next window
            if (i < textLength - patternLength) {

                textHash =
                        (BASE * (textHash
                                - text.charAt(i)
                                * highestPower)
                                + text.charAt(
                                        i + patternLength))
                                % PRIME;

                if (textHash < 0) {
                    textHash += PRIME;
                }
            }
        }

        return -1;
    }


    /**
     * Rabin-Karp search with performance statistics.
     *
     * This uses the same Rabin-Karp algorithm as
     * the original search() method, but additionally
     * records:
     *
     * 1. Hash comparisons
     * 2. Character comparisons
     * 3. Execution time
     * 4. Match position
     *
     * This method is used for the DSA comparison
     * with KMP.
     */
    public static AlgorithmStats searchWithStats(
            String text,
            String pattern) {

        long startTime = System.nanoTime();

        if (text == null || pattern == null) {

            return new AlgorithmStats(
                    -1,
                    0,
                    0,
                    0
            );
        }

        if (pattern.length() == 0) {

            long executionTime =
                    System.nanoTime() - startTime;

            return new AlgorithmStats(
                    0,
                    0,
                    0,
                    executionTime
            );
        }

        if (pattern.length() > text.length()) {

            long executionTime =
                    System.nanoTime() - startTime;

            return new AlgorithmStats(
                    -1,
                    0,
                    0,
                    executionTime
            );
        }

        int patternLength =
                pattern.length();

        int textLength =
                text.length();

        long patternHash = 0;
        long textHash = 0;

        long highestPower = 1;

        // Statistics
        long hashComparisons = 0;
        long characterComparisons = 0;

        // Calculate BASE^(patternLength - 1)
        for (int i = 0;
             i < patternLength - 1;
             i++) {

            highestPower =
                    (highestPower * BASE)
                            % PRIME;
        }

        // Calculate initial hash values
        for (int i = 0;
             i < patternLength;
             i++) {

            patternHash =
                    (BASE * patternHash
                            + pattern.charAt(i))
                            % PRIME;

            textHash =
                    (BASE * textHash
                            + text.charAt(i))
                            % PRIME;
        }

        // Slide the pattern across the text
        for (int i = 0;
             i <= textLength - patternLength;
             i++) {

            /*
             * Count every comparison between
             * pattern hash and current text hash.
             */
            hashComparisons++;

            // If hashes match, verify characters
            if (patternHash == textHash) {

                boolean match = true;

                for (int j = 0;
                     j < patternLength;
                     j++) {

                    /*
                     * Count character comparison.
                     */
                    characterComparisons++;

                    if (text.charAt(i + j)
                            != pattern.charAt(j)) {

                        match = false;
                        break;
                    }
                }

                if (match) {

                    long executionTime =
                            System.nanoTime()
                                    - startTime;

                    return new AlgorithmStats(
                            i,
                            characterComparisons,
                            hashComparisons,
                            executionTime
                    );
                }
            }

            // Calculate hash for next window
            if (i < textLength - patternLength) {

                textHash =
                        (BASE * (textHash
                                - text.charAt(i)
                                * highestPower)
                                + text.charAt(
                                        i + patternLength))
                                % PRIME;

                if (textHash < 0) {
                    textHash += PRIME;
                }
            }
        }

        long executionTime =
                System.nanoTime() - startTime;

        return new AlgorithmStats(
                -1,
                characterComparisons,
                hashComparisons,
                executionTime
        );
    }
}