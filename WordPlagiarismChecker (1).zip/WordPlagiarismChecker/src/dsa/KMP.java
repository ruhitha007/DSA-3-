package dsa;

public class KMP {

    /**
     * Searches for a pattern inside a text using
     * the Knuth-Morris-Pratt (KMP) algorithm.
     *
     * This is the original method used by the project.
     *
     * @param text    the text to search in
     * @param pattern the pattern to find
     * @return starting index of the pattern, or -1 if not found
     */
    public static int search(String text, String pattern) {

        if (text == null || pattern == null) {
            return -1;
        }

        if (pattern.length() == 0) {
            return 0;
        }

        int[] lps = buildLPS(pattern);

        int i = 0;
        int j = 0;

        while (i < text.length()) {

            if (text.charAt(i) == pattern.charAt(j)) {

                i++;
                j++;

                if (j == pattern.length()) {
                    return i - j;
                }

            } else {

                if (j != 0) {

                    j = lps[j - 1];

                } else {

                    i++;
                }
            }
        }

        return -1;
    }


    /**
     * KMP search with performance statistics.
     *
     * This method is used for comparing KMP
     * against Rabin-Karp.
     *
     * It records:
     *
     * 1. Match position
     * 2. Number of character comparisons
     * 3. Execution time
     *
     * @param text    text to search in
     * @param pattern pattern to find
     * @return AlgorithmStats containing KMP performance data
     */
    public static AlgorithmStats searchWithStats(
            String text,
            String pattern) {

        long startTime = System.nanoTime();

        // Handle invalid input
        if (text == null || pattern == null) {

            return new AlgorithmStats(
                    -1,
                    0,
                    0,
                    0
            );
        }

        // Empty pattern
        if (pattern.length() == 0) {

            long executionTime =
                    System.nanoTime() - startTime;

            return new AlgorithmStats(
                    0,
                    0,
                    0,
                    executionTime
            );
        }

        // Pattern longer than text
        if (pattern.length() > text.length()) {

            long executionTime =
                    System.nanoTime() - startTime;

            return new AlgorithmStats(
                    -1,
                    0,
                    0,
                    executionTime
            );
        }

        // Build LPS array
        int[] lps = buildLPS(pattern);

        int i = 0;
        int j = 0;

        long comparisons = 0;

        /*
         * Main KMP searching process
         */
        while (i < text.length()) {

            // Count character comparison
            comparisons++;

            if (text.charAt(i)
                    == pattern.charAt(j)) {

                i++;
                j++;

                /*
                 * Complete pattern found
                 */
                if (j == pattern.length()) {

                    long executionTime =
                            System.nanoTime()
                                    - startTime;

                    return new AlgorithmStats(
                            i - j,
                            comparisons,
                            0,
                            executionTime
                    );
                }

            } else {

                /*
                 * KMP uses the LPS array to
                 * avoid unnecessary comparisons.
                 */
                if (j != 0) {

                    j = lps[j - 1];

                } else {

                    i++;
                }
            }
        }

        /*
         * Pattern was not found
         */
        long executionTime =
                System.nanoTime() - startTime;

        return new AlgorithmStats(
                -1,
                comparisons,
                0,
                executionTime
        );
    }


    /**
     * Builds the Longest Prefix Suffix (LPS) array.
     *
     * LPS[i] stores the length of the longest
     * proper prefix of the pattern that is also
     * a suffix of the pattern up to index i.
     */
    private static int[] buildLPS(String pattern) {

        int[] lps =
                new int[pattern.length()];

        int length = 0;

        int i = 1;

        while (i < pattern.length()) {

            if (pattern.charAt(i)
                    == pattern.charAt(length)) {

                length++;

                lps[i] = length;

                i++;

            } else {

                if (length != 0) {

                    /*
                     * Do not increment i here.
                     * We use the previously calculated
                     * LPS value.
                     */
                    length =
                            lps[length - 1];

                } else {

                    lps[i] = 0;

                    i++;
                }
            }
        }

        return lps;
    }
}