package dsa;

public class AlgorithmStats {

    private int matchPosition;
    private long comparisons;
    private long hashComparisons;
    private long executionTime;

    public AlgorithmStats(
            int matchPosition,
            long comparisons,
            long hashComparisons,
            long executionTime) {

        this.matchPosition = matchPosition;
        this.comparisons = comparisons;
        this.hashComparisons = hashComparisons;
        this.executionTime = executionTime;
    }

    public int getMatchPosition() {
        return matchPosition;
    }

    public long getComparisons() {
        return comparisons;
    }

    public long getHashComparisons() {
        return hashComparisons;
    }

    public long getExecutionTime() {
        return executionTime;
    }
}