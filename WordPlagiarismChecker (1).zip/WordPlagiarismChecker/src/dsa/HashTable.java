package dsa;

import java.util.ArrayList;
import java.util.List;

public class HashTable {

    private static class Node {

        String key;
        List<Integer> positions;
        Node next;

        Node(String key, int position) {

            this.key = key;

            positions = new ArrayList<>();
            positions.add(position);

            next = null;
        }
    }

    private Node[] table;
    private int size;

    public HashTable(int size) {

        this.size = size;
        table = new Node[size];
    }

    private int hash(String key) {

        int hash = 0;

        for (int i = 0; i < key.length(); i++) {

            hash = (hash * 31 + key.charAt(i)) % size;
        }

        return hash;
    }

    public void insert(String key, int position) {

        int index = hash(key);

        Node current = table[index];

        // If bucket is empty
        if (current == null) {

            table[index] =
                    new Node(key, position);

            return;
        }

        // Search for existing key
        while (true) {

            if (current.key.equals(key)) {

                current.positions.add(position);

                return;
            }

            if (current.next == null) {
                break;
            }

            current = current.next;
        }

        // Collision: add new node
        current.next =
                new Node(key, position);
    }

    public List<Integer> search(String key) {

        int index = hash(key);

        Node current = table[index];

        while (current != null) {

            if (current.key.equals(key)) {

                return current.positions;
            }

            current = current.next;
        }

        return new ArrayList<>();
    }
}