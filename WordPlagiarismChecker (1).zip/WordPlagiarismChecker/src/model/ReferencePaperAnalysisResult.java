package model;

import java.util.List;

/*
 * A single external reference paper analysis result.
 *
 * Each entry holds the reference metadata, the independent
 * plagiarism comparison against the uploaded document, and
 * the KMP / Rabin-Karp statistics for that reference only.
 */
public class ReferencePaperAnalysisResult {

    private DashboardAnalysisResponse.ReferencePaper
            referencePaper;

    private double similarity;
    private int totalWords;
    private int matchedWords;

    private DashboardAnalysisResponse.KMPStats kmp;
    private DashboardAnalysisResponse.RabinKarpStats rabinKarp;
    private String observation;

    private List<MatchResult> matches;

    public ReferencePaperAnalysisResult(
            DashboardAnalysisResponse.ReferencePaper
                    referencePaper,
            PlagiarismResult result,
            DSAComparisonResult dsa) {

        this.referencePaper = referencePaper;

        this.similarity =
                result.getSimilarity();

        this.totalWords =
                result.getTotalWords();

        this.matchedWords =
                result.getMatchedWords();

        this.matches =
                result.getMatches();

        if (dsa != null) {

            this.observation =
                    dsa.getObservation();

            this.kmp =
                    new DashboardAnalysisResponse.KMPStats(
                            dsa.getKmpMatches(),
                            dsa.getKmpCharacterComparisons(),
                            dsa.getKmpExecutionTime()
                    );

            this.rabinKarp =
                    new DashboardAnalysisResponse.RabinKarpStats(
                            dsa.getRabinKarpMatches(),
                            dsa.getRabinKarpHashComparisons(),
                            dsa.getRabinKarpCharacterComparisons(),
                            dsa.getRabinKarpExecutionTime()
                    );
        }
    }

    public DashboardAnalysisResponse.ReferencePaper
            getReferencePaper() {
        return referencePaper;
    }

    public double getSimilarity() {
        return similarity;
    }

    public int getTotalWords() {
        return totalWords;
    }

    public int getMatchedWords() {
        return matchedWords;
    }

    public DashboardAnalysisResponse.KMPStats getKmp() {
        return kmp;
    }

    public DashboardAnalysisResponse.RabinKarpStats
            getRabinKarp() {
        return rabinKarp;
    }

    public String getObservation() {
        return observation;
    }

    public List<MatchResult> getMatches() {
        return matches;
    }
}