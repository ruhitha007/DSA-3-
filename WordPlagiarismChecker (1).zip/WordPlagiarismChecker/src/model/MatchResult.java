package model;

public class MatchResult {

    private String matchedText;
    private int userPosition;
    private int sourcePosition;
    private double similarity;

    public MatchResult(
            String matchedText,
            int userPosition,
            int sourcePosition,
            double similarity) {

        this.matchedText = matchedText;
        this.userPosition = userPosition;
        this.sourcePosition = sourcePosition;
        this.similarity = similarity;
    }

    public String getMatchedText() {
        return matchedText;
    }

    public int getUserPosition() {
        return userPosition;
    }

    public int getSourcePosition() {
        return sourcePosition;
    }

    public double getSimilarity() {
        return similarity;
    }

    @Override
    public String toString() {

        return "Matched Text: \"" + matchedText + "\"" +
                "\nUser Position: " + userPosition +
                "\nSource Position: " + sourcePosition +
                "\nSimilarity: " +
                String.format("%.2f", similarity) + "%";
    }
}