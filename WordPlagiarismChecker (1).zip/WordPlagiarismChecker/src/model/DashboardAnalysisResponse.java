package model;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

public class DashboardAnalysisResponse {

    private String status;
    private PlagiarismSummary plagiarism;
    private List<MatchResult> matches;
    private DSAComparison dsaComparison;
    private ReferencePaper referencePaper;
    private String message;
    private List<ReferencePaperAnalysisResult> referencePapers;

    public DashboardAnalysisResponse(
            String status,
            PlagiarismResult plagiarismResult,
            List<MatchResult> matches,
            DSAComparisonResult dsaResult,
            ReferencePaper referencePaper,
            String message) {

        this.status = status;

        this.plagiarism =
                new PlagiarismSummary(plagiarismResult);

        this.matches = matches;

        this.dsaComparison =
                dsaResult == null
                        ? null
                        : new DSAComparison(dsaResult);

        this.referencePaper = referencePaper;

        this.message = message;
    }

    /*
     * Multi-reference constructor.
     *
     * The overall plagiarism score, matched text list and
     * DSA comparison are derived from the reference paper
     * with the HIGHEST similarity (never a sum of
     * percentages). The individual per-reference analyses
     * stay available under referencePapers.
     */
    public DashboardAnalysisResponse(
            String status,
            List<ReferencePaperAnalysisResult> referencePapers,
            String message) {

        this.status = status;
        this.message = message;
        this.referencePapers = referencePapers;

        ReferencePaperAnalysisResult top = null;

        if (referencePapers != null) {

            for (ReferencePaperAnalysisResult ref
                    : referencePapers) {

                if (top == null
                        || ref.getSimilarity()
                                > top.getSimilarity()) {

                    top = ref;
                }
            }
        }

        if (top == null) {
            return;
        }

        this.plagiarism =
                new PlagiarismSummary(
                        top.getTotalWords(),
                        top.getMatchedWords(),
                        top.getSimilarity()
                );

        this.matches = top.getMatches();

        if (top.getKmp() != null
                && top.getRabinKarp() != null) {

            this.dsaComparison =
                    new DSAComparison(top);
        }

        this.referencePaper =
                top.getReferencePaper();
    }

    public String getStatus() {
        return status;
    }

    public PlagiarismSummary getPlagiarism() {
        return plagiarism;
    }

    public List<MatchResult> getMatches() {
        return matches;
    }

    public DSAComparison getDsaComparison() {
        return dsaComparison;
    }

    public ReferencePaper getReferencePaper() {
        return referencePaper;
    }

    public String getMessage() {
        return message;
    }

    public List<ReferencePaperAnalysisResult>
            getReferencePapers() {
        return referencePapers;
    }


    /*
     * Nested summary object for the plagiarism
     * statistics section of the response.
     */
    public static class PlagiarismSummary {

        private int totalWords;
        private int matchedWords;
        private double similarity;

        public PlagiarismSummary(
                PlagiarismResult result) {

            this.totalWords =
                    result.getTotalWords();

            this.matchedWords =
                    result.getMatchedWords();

            this.similarity =
                    round(result.getSimilarity());
        }

        public PlagiarismSummary(
                int totalWords,
                int matchedWords,
                double similarity) {

            this.totalWords = totalWords;
            this.matchedWords = matchedWords;
            this.similarity = round(similarity);
        }

        public int getTotalWords() {
            return totalWords;
        }

        public int getMatchedWords() {
            return matchedWords;
        }

        public double getSimilarity() {
            return similarity;
        }
    }


    /*
     * Nested object for the DSA comparison
     * statistics section of the response.
     */
    public static class DSAComparison {

        private KMPStats kmp;
        private RabinKarpStats rabinKarp;
        private String observation;

        public DSAComparison(
                DSAComparisonResult result) {

            this.kmp =
                    new KMPStats(
                            result.getKmpMatches(),
                            result.getKmpCharacterComparisons(),
                            result.getKmpExecutionTime()
                    );

            this.rabinKarp =
                    new RabinKarpStats(
                            result.getRabinKarpMatches(),
                            result.getRabinKarpHashComparisons(),
                            result.getRabinKarpCharacterComparisons(),
                            result.getRabinKarpExecutionTime()
                    );

            this.observation =
                    result.getObservation();
        }

        public DSAComparison(
                ReferencePaperAnalysisResult result) {

            this.kmp =
                    new KMPStats(
                            result.getKmp()
                                    .getMatchesFound(),
                            result.getKmp()
                                    .getCharacterComparisons(),
                            result.getKmp()
                                    .getExecutionTimeMs()
                    );

            this.rabinKarp =
                    new RabinKarpStats(
                            result.getRabinKarp()
                                    .getMatchesFound(),
                            result.getRabinKarp()
                                    .getHashComparisons(),
                            result.getRabinKarp()
                                    .getCharacterComparisons(),
                            result.getRabinKarp()
                                    .getExecutionTimeMs()
                    );

            this.observation =
                    result.getObservation();
        }

        public KMPStats getKmp() {
            return kmp;
        }

        public RabinKarpStats getRabinKarp() {
            return rabinKarp;
        }

        public String getObservation() {
            return observation;
        }
    }


    /*
     * KMP statistics section.
     */
    public static class KMPStats {

        private int matchesFound;
        private long characterComparisons;
        private double executionTimeMs;

        public KMPStats(
                int matchesFound,
                long characterComparisons,
                double executionTimeMs) {

            this.matchesFound = matchesFound;
            this.characterComparisons =
                    characterComparisons;
            this.executionTimeMs =
                    round(executionTimeMs);
        }

        public int getMatchesFound() {
            return matchesFound;
        }

        public long getCharacterComparisons() {
            return characterComparisons;
        }

        public double getExecutionTimeMs() {
            return executionTimeMs;
        }
    }


    /*
     * Rabin-Karp statistics section.
     */
    public static class RabinKarpStats {

        private int matchesFound;
        private long hashComparisons;
        private long characterComparisons;
        private double executionTimeMs;

        public RabinKarpStats(
                int matchesFound,
                long hashComparisons,
                long characterComparisons,
                double executionTimeMs) {

            this.matchesFound = matchesFound;
            this.hashComparisons = hashComparisons;
            this.characterComparisons =
                    characterComparisons;
            this.executionTimeMs =
                    round(executionTimeMs);
        }

        public int getMatchesFound() {
            return matchesFound;
        }

        public long getHashComparisons() {
            return hashComparisons;
        }

        public long getCharacterComparisons() {
            return characterComparisons;
        }

        public double getExecutionTimeMs() {
            return executionTimeMs;
        }
    }


    /*
     * Reference paper metadata section.
     */
    public static class ReferencePaper {

        private String paperId;
        private String title;
        private List<String> authors;
        private Integer year;
        private String url;
        private String openAccessPdf;

        public ReferencePaper(
                String paperId,
                String title,
                List<String> authors,
                Integer year,
                String url,
                String openAccessPdf) {

            this.paperId = paperId;
            this.title = title;
            this.authors = authors;
            this.year = year;
            this.url = url;
            this.openAccessPdf = openAccessPdf;
        }

        public String getPaperId() {
            return paperId;
        }

        public String getTitle() {
            return title;
        }

        public List<String> getAuthors() {
            return authors;
        }

        public Integer getYear() {
            return year;
        }

        public String getUrl() {
            return url;
        }

        public String getOpenAccessPdf() {
            return openAccessPdf;
        }


        /*
         * Builds a ReferencePaper from the JsonObject
         * returned by SemanticScholarClient.
         *
         * Fields that are missing or null become
         * empty strings / null year.
         */
        public static ReferencePaper fromPaper(
                JsonObject paper) {

            String paperId =
                    getString(paper, "paperId");

            String title =
                    getString(paper, "title");

            String url =
                    getString(paper, "url");

            List<String> authors =
                    new ArrayList<>();

            if (paper.has("authors")
                    && !paper.get("authors")
                            .isJsonNull()) {

                JsonArray authorArray =
                        paper.getAsJsonArray(
                                "authors"
                        );

                for (int i = 0;
                     i < authorArray.size();
                     i++) {

                    JsonObject author =
                            authorArray.get(i)
                                    .getAsJsonObject();

                    authors.add(
                            getString(author, "name")
                    );
                }
            }

            Integer year = null;

            if (paper.has("year")
                    && !paper.get("year").isJsonNull()
                    && paper.get("year")
                            .isJsonPrimitive()) {

                year = paper.get("year")
                        .getAsInt();
            }

            String openAccessPdf = "";

            if (paper.has("openAccessPdf")
                    && !paper.get("openAccessPdf")
                            .isJsonNull()) {

                openAccessPdf =
                        getString(
                                paper.getAsJsonObject(
                                        "openAccessPdf"
                                ),
                                "url"
                        );
            }

            return new ReferencePaper(
                    paperId,
                    title,
                    authors,
                    year,
                    url,
                    openAccessPdf
            );
        }

        private static String getString(
                JsonObject object,
                String field) {

            if (!object.has(field)
                    || object.get(field)
                            .isJsonNull()) {

                return "";
            }

            return object.get(field)
                    .getAsString();
        }
    }


    /*
     * Round to two decimal places for cleaner output.
     */
    private static double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}