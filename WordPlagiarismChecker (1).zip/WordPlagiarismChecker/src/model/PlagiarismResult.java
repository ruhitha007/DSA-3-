package model;

import java.util.List;

public class PlagiarismResult {

    private int totalWords;
    private int matchedWords;
    private double similarity;
    private List<MatchResult> matches;

    public PlagiarismResult(
            int totalWords,
            int matchedWords,
            double similarity,
            List<MatchResult> matches) {

        this.totalWords = totalWords;
        this.matchedWords = matchedWords;
        this.similarity = similarity;
        this.matches = matches;
    }

    public int getTotalWords() {
        return totalWords;
    }

    public int getMatchedWords() {
        return matchedWords;
    }

    public double getSimilarity() {
        return similarity;
    }

    public List<MatchResult> getMatches() {
        return matches;
    }

    @Override
    public String toString() {

        StringBuilder result = new StringBuilder();

        result.append("\n-------------------------\n");
        result.append("PLAGIARISM RESULT\n");
        result.append("-------------------------\n");

        result.append("Total words: ")
                .append(totalWords)
                .append("\n");

        result.append("Matched words: ")
                .append(matchedWords)
                .append("\n");

        result.append("Similarity: ")
                .append(String.format("%.2f", similarity))
                .append("%\n");

        result.append("\nMATCHES:\n");

        for (MatchResult match : matches) {

            result.append("\n")
                    .append(match)
                    .append("\n");
        }

        return result.toString();
    }
}
