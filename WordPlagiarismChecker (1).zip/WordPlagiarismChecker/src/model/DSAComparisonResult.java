package model;

public class DSAComparisonResult {

    private int kmpMatches;
    private long kmpCharacterComparisons;
    private double kmpExecutionTime;

    private int rabinKarpMatches;
    private long rabinKarpHashComparisons;
    private long rabinKarpCharacterComparisons;
    private double rabinKarpExecutionTime;

    private String observation;

    public DSAComparisonResult(
            int kmpMatches,
            long kmpCharacterComparisons,
            double kmpExecutionTime,
            int rabinKarpMatches,
            long rabinKarpHashComparisons,
            long rabinKarpCharacterComparisons,
            double rabinKarpExecutionTime,
            String observation) {

        this.kmpMatches = kmpMatches;
        this.kmpCharacterComparisons =
                kmpCharacterComparisons;
        this.kmpExecutionTime =
                kmpExecutionTime;

        this.rabinKarpMatches =
                rabinKarpMatches;
        this.rabinKarpHashComparisons =
                rabinKarpHashComparisons;
        this.rabinKarpCharacterComparisons =
                rabinKarpCharacterComparisons;
        this.rabinKarpExecutionTime =
                rabinKarpExecutionTime;

        this.observation = observation;
    }

    public int getKmpMatches() {
        return kmpMatches;
    }

    public long getKmpCharacterComparisons() {
        return kmpCharacterComparisons;
    }

    public double getKmpExecutionTime() {
        return kmpExecutionTime;
    }

    public int getRabinKarpMatches() {
        return rabinKarpMatches;
    }

    public long getRabinKarpHashComparisons() {
        return rabinKarpHashComparisons;
    }

    public long getRabinKarpCharacterComparisons() {
        return rabinKarpCharacterComparisons;
    }

    public double getRabinKarpExecutionTime() {
        return rabinKarpExecutionTime;
    }

    public String getObservation() {
        return observation;
    }
}