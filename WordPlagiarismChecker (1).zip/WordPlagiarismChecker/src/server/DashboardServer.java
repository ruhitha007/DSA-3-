package server;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import model.DSAComparisonResult;
import model.DashboardAnalysisResponse;
import model.PlagiarismResult;
import model.ReferencePaperAnalysisResult;
import plagiarism.PlagiarismEngine;
import processing.PDFDownloader;
import processing.PDFTextExtractor;
import processing.QueryBuilder;
import search.SemanticScholarClient;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class DashboardServer {

    private static final int PORT = 8080;

    /*
     * React/Vite development server origin.
     */
    private static final String ALLOWED_ORIGIN =
            "http://localhost:5173";

    /*
     * TEMPORARY:
     * This is the source PDF we are currently using
     * to test the plagiarism engine.
     *
     * We will remove this later and use the
     * reference PDFs obtained from Semantic Scholar.
     */
    private static final String SOURCE_PDF =
            "C:\\Users\\anany\\OneDrive\\Desktop\\WordPlagiarismChecker\\source.pdf";

    /*
     * Multi-reference configuration:
     *
     * We look for up to MAX_REFERENCE_PAPERS usable
     * external reference papers, and give up (using
     * whatever was collected) once the search has run
     * for MAX_REFERENCE_SEARCH_MS.
     */
    private static final int MAX_REFERENCE_PAPERS = 3;
    private static final long MAX_REFERENCE_SEARCH_MS = 45000;


    public static void main(String[] args)
            throws Exception {

        HttpServer server =
                HttpServer.create(
                        new InetSocketAddress(PORT),
                        0
                );

        /*
         * Test endpoint
         */
        server.createContext(
                "/api/health",
                DashboardServer::health
        );

        /*
         * Plagiarism analysis endpoint
         */
        server.createContext(
                "/api/analyze",
                DashboardServer::analyze
        );

        server.start();

        System.out.println();
        System.out.println("========================================");
        System.out.println("PLAGIARISM DASHBOARD BACKEND");
        System.out.println("========================================");

        System.out.println(
                "Server running at:"
        );

        System.out.println(
                "http://localhost:" + PORT
        );

        System.out.println();

        System.out.println("APIs:");

        System.out.println(
                "GET  http://localhost:"
                        + PORT
                        + "/api/health"
        );

        System.out.println(
                "POST http://localhost:"
                        + PORT
                        + "/api/analyze"
        );

        System.out.println(
                "========================================"
        );
    }


    /*
     * Health check
     */
    private static void health(
            HttpExchange exchange)
            throws IOException {

        applyCors(exchange);

        String response =
                """
                {
                    "status": "running",
                    "message": "Plagiarism backend is working"
                }
                """;

        sendJson(
                exchange,
                200,
                response
        );
    }


    /*
     * Analyze uploaded PDF
     */
    private static void analyze(
            HttpExchange exchange)
            throws IOException {

        /*
         * CORS headers on every response,
         * including preflight checks.
         */
        applyCors(exchange);

        /*
         * Handle OPTIONS preflight requests
         * sent by the React/Vite development server.
         */
        if (exchange.getRequestMethod()
                .equalsIgnoreCase("OPTIONS")) {

            exchange.sendResponseHeaders(204, -1);
            exchange.close();
            return;
        }

        /*
         * Only POST is allowed
         */
        if (!exchange.getRequestMethod()
                .equalsIgnoreCase("POST")) {

            sendJson(
                    exchange,
                    405,
                    """
                    {
                        "error": "Only POST requests are allowed"
                    }
                    """
            );

            return;
        }


        Path userPdf = null;

        try {

            System.out.println();
            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "NEW PDF ANALYSIS REQUEST"
            );

            System.out.println(
                    "========================================"
            );


            /*
             * Create temporary file
             * for uploaded PDF
             */
            userPdf =
                    Files.createTempFile(
                            "uploaded-paper-",
                            ".pdf"
                    );


            /*
             * Read uploaded PDF
             */
            try (InputStream input =
                         exchange.getRequestBody()) {

                Files.copy(
                        input,
                        userPdf,
                        java.nio.file.StandardCopyOption
                                .REPLACE_EXISTING
                );
            }


            System.out.println(
                    "User PDF received."
            );


            /*
             * Extract user PDF text
             */
            String userText =
                    PDFTextExtractor.extractText(
                            userPdf.toString()
                    );


            System.out.println(
                    "User PDF extracted."
            );

            System.out.println(
                    "Characters: "
                            + userText.length()
            );


            /*
             * Build a search query from the
             * uploaded document.
             */
            String query =
                    QueryBuilder.buildQuery(userText);

            System.out.println(
                    "Reference search query: " + query
            );


            /*
             * Attempt the Semantic Scholar pipeline:
             *
             * search → try each paper with an open-access
             * PDF → download → extract reference text.
             */
            String referenceText = null;
            List<ReferencePaperAnalysisResult>
                    referenceResults =
                            new ArrayList<>();

            try {

                List<JsonObject> papers =
                        SemanticScholarClient
                                .searchPapers(query);

                int candidateIndex = 0;

                long searchStart =
                        System.currentTimeMillis();

                System.out.println(
                        "Reference search started."
                );

                for (JsonObject paper : papers) {

                    candidateIndex++;

                    if (referenceResults.size()
                            >= MAX_REFERENCE_PAPERS) {

                        System.out.println(
                                "Collected the maximum of "
                                        + MAX_REFERENCE_PAPERS
                                        + " reference papers."
                        );

                        break;
                    }

                    if (System.currentTimeMillis()
                                    - searchStart
                            >= MAX_REFERENCE_SEARCH_MS) {

                        System.out.println(
                                "Reference search time budget "
                                        + "reached."
                        );

                        break;
                    }

                    if (!paper.has("openAccessPdf")
                            || paper.get("openAccessPdf")
                                    .isJsonNull()) {

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + " skipped: no open access PDF."
                        );

                        continue;
                    }

                    JsonObject pdf =
                            paper.getAsJsonObject(
                                    "openAccessPdf"
                            );

                    if (!pdf.has("url")
                            || pdf.get("url").isJsonNull()
                            || pdf.get("url")
                                    .getAsString()
                                    .isBlank()) {

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + " skipped: blank PDF URL."
                        );

                        continue;
                    }

                    String pdfUrl =
                            pdf.get("url").getAsString();

                    Path referencePdf = null;
                    boolean extractionPhase = false;

                    try {

                        referencePdf =
                                Files.createTempFile(
                                        "reference-paper-",
                                        ".pdf"
                                );

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + ": downloading reference PDF: "
                                        + pdfUrl
                        );

                        long downloadStart =
                                System.currentTimeMillis();

                        boolean downloaded =
                                PDFDownloader.downloadPDF(
                                        pdfUrl,
                                        referencePdf.toString()
                                );

                        long downloadMs =
                                System.currentTimeMillis()
                                        - downloadStart;

                        if (!downloaded) {

                            System.out.println(
                                    "Candidate "
                                            + candidateIndex
                                            + " failed: PDF download failed "
                                            + "(" + downloadMs + " ms)."
                            );

                            continue;
                        }

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + ": download completed ("
                                        + downloadMs + " ms)."
                        );

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + ": extracting text..."
                        );

                        extractionPhase = true;

                        long extractStart =
                                System.currentTimeMillis();

                        referenceText =
                                PDFTextExtractor.extractText(
                                        referencePdf.toString()
                                );

                        long extractMs =
                                System.currentTimeMillis()
                                        - extractStart;

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + ": extraction completed ("
                                        + extractMs + " ms)."
                        );

                    } catch (SocketTimeoutException e) {

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + " failed: download timeout."
                        );

                        continue;

                    } catch (Exception e) {

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + " failed: "
                                        + (extractionPhase
                                                ? "extraction error: "
                                                : "download error: ")
                                        + e.getMessage()
                        );

                        continue;

                    } finally {

                        if (referencePdf != null) {

                            try {

                                Files.deleteIfExists(
                                        referencePdf
                                );

                            } catch (Exception ignored) {
                            }
                        }
                    }

                    if (referenceText == null
                            || referenceText.isBlank()) {

                        System.out.println(
                                "Candidate "
                                        + candidateIndex
                                        + " failed: reference PDF "
                                        + "contained no extractable text."
                        );

                        referenceText = null;

                        continue;
                    }

                    System.out.println(
                            "Candidate "
                                    + candidateIndex
                                    + ": selected. "
                                    + "Reference paper: "
                                    + pdfUrl
                    );

                    /*
                     * Run the plagiarism engine + DSA
                     * independently against THIS reference.
                     */
                    PlagiarismEngine engine =
                            new PlagiarismEngine(
                                    100,
                                    3
                            );

                    engine.addSourceDocument(
                            referenceText
                    );

                    PlagiarismResult refResult =
                            engine.analyze(
                                    userText
                            );

                    DSAComparisonResult refDsa =
                            engine.getDSAResult();

                    referenceResults.add(
                            new ReferencePaperAnalysisResult(
                                    DashboardAnalysisResponse
                                            .ReferencePaper
                                            .fromPaper(
                                                    paper
                                            ),
                                    refResult,
                                    refDsa
                            )
                    );

                    System.out.println(
                            "Reference "
                                    + referenceResults.size()
                                    + " selected: "
                                    + pdfUrl
                    );

                    System.out.println(
                            "Reference "
                                    + referenceResults.size()
                                    + " similarity: "
                                    + refResult.getSimilarity()
                                    + "%"
                    );

                    referenceText = null;
                }

                long searchElapsed =
                        System.currentTimeMillis()
                                - searchStart;

                System.out.println(
                        "Reference search completed in "
                                + searchElapsed
                                + " ms"
                );

                System.out.println(
                        "Total references selected: "
                                + referenceResults.size()
                );

                if (referenceResults.isEmpty()) {

                    System.out.println(
                            "No usable reference paper was "
                                    + "found among all candidates."
                    );
                }

            } catch (Exception e) {

                System.out.println(
                        "Semantic Scholar pipeline failed: "
                                + e.getMessage()
                );

                referenceText = null;
                referenceResults.clear();
            }


            /*
             * Fallback to the temporary source.pdf
             * while the full pipeline is being
             * verified.
             */
            String message =
                    "Analysis completed successfully";

            boolean usedFallback =
                    referenceResults.isEmpty();

            if (usedFallback) {

                if (!Files.exists(
                        Path.of(SOURCE_PDF))) {

                    sendJson(
                            exchange,
                            500,
                            """
                            {
                                "error": "No reference PDF available"
                            }
                            """
                    );

                    return;
                }

                referenceText =
                        PDFTextExtractor.extractText(
                                SOURCE_PDF
                        );

                message =
                        "Analysis completed successfully "
                                + "(fallback: source.pdf used)";

                System.out.println(
                        "Using temporary fallback source.pdf"
                );
            }


            /*
             * If external references were collected, the
             * overall score comes from the highest-similarity
             * reference. Otherwise (0 references) run the
             * single-engine fallback against source.pdf.
             */
            DashboardAnalysisResponse response;

            if (usedFallback) {

                /*
                 * Create plagiarism engine
                 */
                PlagiarismEngine engine =
                        new PlagiarismEngine(
                                100,
                                3
                        );


                /*
                 * Add reference document
                 */
                engine.addSourceDocument(
                        referenceText
                );


                /*
                 * Analyze user document
                 */
                PlagiarismResult result =
                        engine.analyze(
                                userText
                        );


                System.out.println(
                        "Plagiarism analysis completed."
                );

                System.out.println(
                        "Similarity: "
                                + result.getSimilarity()
                                + "%"
                );


                /*
                 * Collect DSA comparison stats.
                 */
                DSAComparisonResult dsaResult =
                        engine.getDSAResult();


                response =
                        new DashboardAnalysisResponse(
                                "success",
                                result,
                                result.getMatches(),
                                dsaResult,
                                null,
                                message
                        );

            } else {

                message =
                        "Analysis completed successfully ("
                                + referenceResults.size()
                                + " external reference papers analyzed)";

                System.out.println(
                        "External references used: "
                                + referenceResults.size()
                );

                response =
                        new DashboardAnalysisResponse(
                                "success",
                                referenceResults,
                                message
                        );
            }

            String json =
                    new Gson()
                            .toJson(response);


            sendJson(
                    exchange,
                    200,
                    json
            );


        } catch (Exception e) {

            e.printStackTrace();


            String error =
                    "{"
                    + "\"status\":\"error\","
                    + "\"message\":\""
                    + escapeJson(
                            e.getMessage()
                    )
                    + "\""
                    + "}";


            sendJson(
                    exchange,
                    500,
                    error
            );


        } finally {

            /*
             * Delete temporary uploaded PDF
             */
            if (userPdf != null) {

                try {

                    Files.deleteIfExists(
                            userPdf
                    );

                } catch (Exception ignored) {
                }
            }
        }
    }


    /*
     * Apply CORS headers so the React/Vite
     * development server can call this backend.
     */
    private static void applyCors(
            HttpExchange exchange) {

        exchange.getResponseHeaders()
                .set(
                        "Access-Control-Allow-Origin",
                        ALLOWED_ORIGIN
                );

        exchange.getResponseHeaders()
                .set(
                        "Access-Control-Allow-Methods",
                        "GET, POST, OPTIONS"
                );

        exchange.getResponseHeaders()
                .set(
                        "Access-Control-Allow-Headers",
                        "Content-Type, Accept, x-api-key, Authorization"
                );

        exchange.getResponseHeaders()
                .set(
                        "Access-Control-Max-Age",
                        "86400"
                );
    }


    /*
     * Send JSON response
     */
    private static void sendJson(
            HttpExchange exchange,
            int statusCode,
            String response)
            throws IOException {

        exchange.getResponseHeaders()
                .set(
                        "Content-Type",
                        "application/json"
                );


        byte[] responseBytes =
                response.getBytes(
                        java.nio.charset.StandardCharsets.UTF_8
                );


        exchange.sendResponseHeaders(
                statusCode,
                responseBytes.length
        );


        try (OutputStream output =
                     exchange.getResponseBody()) {

            output.write(
                    responseBytes
            );
        }
    }


    /*
     * Escape characters for JSON
     */
    private static String escapeJson(
            String text) {

        if (text == null) {
            return "";
        }

        return text
                .replace(
                        "\\",
                        "\\\\"
                )
                .replace(
                        "\"",
                        "\\\""
                )
                .replace(
                        "\n",
                        "\\n"
                )
                .replace(
                        "\r",
                        "\\r"
                );
    }
}