import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import model.PlagiarismResult;
import plagiarism.PlagiarismEngine;
import processing.PDFTextExtractor;
import search.SemanticScholarClient;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        String userPdf =
                "C:\\Users\\anany\\Downloads\\1201.0490v4.pdf";

        try {

            // ========================================
            // STEP 1: EXTRACT USER PDF
            // ========================================

            String userText =
                    PDFTextExtractor.extractText(userPdf);

            System.out.println(
                    "\n========================================"
            );

            System.out.println(
                    "USER PDF EXTRACTED"
            );

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "Total characters: "
                            + userText.length()
            );


            // ========================================
            // STEP 2: SEARCH SEMANTIC SCHOLAR
            // ========================================

            String searchQuery =
                    "machine learning in Python";

            System.out.println(
                    "\n========================================"
            );

            System.out.println(
                    "SEARCHING SEMANTIC SCHOLAR"
            );

            System.out.println(
                    "========================================"
            );

            List<JsonObject> papers =
                    SemanticScholarClient
                            .searchPapers(searchQuery);


            // ========================================
            // STEP 3: DISPLAY REFERENCE PAPERS
            // ========================================

            System.out.println(
                    "\n========================================"
            );

            System.out.println(
                    "REFERENCE PAPERS FOUND"
            );

            System.out.println(
                    "========================================"
            );

            if (papers.isEmpty()) {

                System.out.println(
                        "No papers found."
                );

                return;
            }

            for (int i = 0;
                 i < papers.size();
                 i++) {

                JsonObject paper =
                        papers.get(i);

                System.out.println(
                        "\nPAPER " + (i + 1)
                );

                System.out.println(
                        "----------------------------------------"
                );

                String title =
                        getString(
                                paper,
                                "title"
                        );

                String year =
                        getString(
                                paper,
                                "year"
                        );

                String paperUrl =
                        getString(
                                paper,
                                "url"
                        );

                System.out.println(
                        "Title: " + title
                );

                System.out.println(
                        "Year: " + year
                );

                System.out.println(
                        "Paper URL: " + paperUrl
                );


                // AUTHORS
                System.out.print(
                        "Authors: "
                );

                if (paper.has("authors")
                        && !paper.get("authors")
                                .isJsonNull()) {

                    JsonArray authors =
                            paper.getAsJsonArray(
                                    "authors"
                            );

                    for (int j = 0;
                         j < authors.size();
                         j++) {

                        JsonObject author =
                                authors.get(j)
                                        .getAsJsonObject();

                        String authorName =
                                getString(
                                        author,
                                        "name"
                                );

                        System.out.print(
                                authorName
                        );

                        if (j < authors.size() - 1) {
                            System.out.print(
                                    ", "
                            );
                        }
                    }
                }

                System.out.println();


                // PDF
                String pdfUrl = "";

                if (paper.has("openAccessPdf")
                        && !paper.get(
                                "openAccessPdf"
                        ).isJsonNull()) {

                    JsonObject pdf =
                            paper.getAsJsonObject(
                                    "openAccessPdf"
                            );

                    pdfUrl =
                            getString(
                                    pdf,
                                    "url"
                            );
                }

                if (pdfUrl.isBlank()) {

                    System.out.println(
                            "PDF Available: NO"
                    );

                } else {

                    System.out.println(
                            "PDF Available: YES"
                    );

                    System.out.println(
                            "PDF URL: " + pdfUrl
                    );
                }
            }


            // ========================================
            // STEP 4: TEMPORARY COMPARISON
            // ========================================
            //
            // We will connect automatic PDF
            // downloading in the next step.
            //
            // For now, use your downloaded
            // source.pdf to prove the comparison.
            // ========================================

            String sourcePdf =
                    "source.pdf";

            String sourceText =
                    PDFTextExtractor.extractText(
                            sourcePdf
                    );

            System.out.println(
                    "\n========================================"
            );

            System.out.println(
                    "SOURCE PDF EXTRACTED"
            );

            System.out.println(
                    "========================================"
            );


            // ========================================
            // STEP 5: PLAGIARISM ANALYSIS
            // ========================================

            PlagiarismEngine engine =
                    new PlagiarismEngine(100, 3);

            engine.addSourceDocument(
                    sourceText
            );

            PlagiarismResult result =
                    engine.analyze(
                            userText
                    );

            System.out.println(result);

        } catch (Exception e) {

            System.out.println(
                    "Error: " + e.getMessage()
            );

            e.printStackTrace();
        }
    }


    private static String getString(
            JsonObject object,
            String field) {

        if (!object.has(field)
                || object.get(field).isJsonNull()) {

            return "Unknown";
        }

        return object.get(field)
                .getAsString();
    }
}