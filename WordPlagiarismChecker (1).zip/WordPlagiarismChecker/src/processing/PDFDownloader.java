package processing;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;

public class PDFDownloader {

    /*
     * Hard wall-clock ceiling for a single download.
     * The read timeout only bounds each individual read(),
     * so a slow-but-steady stream could otherwise trickle
     * forever. This caps the total time per candidate.
     */
    private static final long MAX_TOTAL_DOWNLOAD_MS = 20000;

    public static boolean downloadPDF(
            String pdfUrl,
            String outputPath) throws Exception {

        if (pdfUrl == null || pdfUrl.isBlank()) {

            System.out.println("PDF URL is empty.");
            return false;
        }

        URI uri = URI.create(pdfUrl);
        URL url = uri.toURL();

        HttpURLConnection connection =
                (HttpURLConnection) url.openConnection();

        connection.setRequestMethod("GET");

        connection.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        + "AppleWebKit/537.36 "
                        + "(KHTML, like Gecko) "
                        + "Chrome/153.0.0.0 Safari/537.36"
        );

        connection.setRequestProperty(
                "Accept",
                "application/pdf,application/octet-stream;q=0.9,*/*;q=0.8"
        );

        connection.setRequestProperty(
                "Accept-Language",
                "en-US,en;q=0.9"
        );

        connection.setRequestProperty(
                "Referer",
                "https://www.mdpi.com/"
        );

        connection.setConnectTimeout(5000);
        connection.setReadTimeout(10000);

        try {

            long deadline =
                    System.currentTimeMillis()
                            + MAX_TOTAL_DOWNLOAD_MS;

            int responseCode =
                    connection.getResponseCode();

            if (responseCode != 200) {

                System.out.println(
                        "PDF download failed. HTTP code: "
                                + responseCode
                );

                connection.disconnect();
                return false;
            }

            try (
                    InputStream inputStream =
                            connection.getInputStream();

                    FileOutputStream outputStream =
                            new FileOutputStream(outputPath)
            ) {

                byte[] buffer = new byte[8192];

                int bytesRead;

                while ((bytesRead =
                        inputStream.read(buffer)) != -1) {

                    outputStream.write(
                            buffer,
                            0,
                            bytesRead
                    );

                    if (System.currentTimeMillis()
                            > deadline) {

                        System.out.println(
                                "PDF download exceeded "
                                        + "total time limit."
                        );

                        throw new SocketTimeoutException(
                                "download exceeded "
                                        + "total time limit"
                        );
                    }
                }
            }

        } catch (SocketTimeoutException e) {

            System.out.println(
                    "PDF download timed out."
            );

            System.out.println(
                    "URL: " + pdfUrl
            );

            connection.disconnect();

            throw e;
        }

        connection.disconnect();

        /*
         * Verify the downloaded file is actually a PDF
         * by checking the magic header. An HTML error
         * page can be served with HTTP 200, so the
         * HTTP status alone is not enough.
         */
        try (FileInputStream pdfInput =
                     new FileInputStream(outputPath)) {

            byte[] header = new byte[5];

            int length =
                    pdfInput.read(header);

            String magic =
                    new String(
                            header,
                            0,
                            Math.max(length, 0),
                            java.nio.charset.StandardCharsets.US_ASCII
                    );

            if (length < 5
                    || !magic.equals("%PDF-")) {

                System.out.println(
                        "Downloaded file is not a valid PDF "
                                + "(missing %PDF- header)."
                );

                return false;
            }
        } catch (IOException e) {

            System.out.println(
                    "Failed to validate downloaded PDF: "
                            + e.getMessage()
            );

            return false;
        }

        System.out.println(
                "PDF downloaded successfully!"
        );

        System.out.println(
                "Saved to: " + outputPath
        );

        return true;
    }
}