package processing;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class QueryBuilder {

    /*
     * Small list of common words that make poor
     * search terms. Kept minimal on purpose.
     */
    private static final Set<String> STOPWORDS =
            Set.of(
                    "this", "that", "with", "from", "have",
                    "were", "been", "will", "what", "when",
                    "there", "their", "which", "they", "them",
                    "then", "than", "also", "using", "used",
                    "into", "about", "more", "most", "some",
                    "study", "results", "based", "analysis",
                    "method", "paper"
            );

    private static final int MAX_TERMS = 5;

    /*
     * Builds a simple search query from the most
     * frequent significant words of the document.
     */
    public static String buildQuery(
            String documentText) {

        if (documentText == null
                || documentText.isBlank()) {

            return "";
        }

        List<String> words =
                TextProcessor.tokenize(documentText);

        Map<String, Integer> counts =
                new HashMap<>();

        for (String word : words) {

            if (word.length() > 3
                    && !STOPWORDS.contains(word)) {

                counts.merge(word, 1, Integer::sum);
            }
        }

        return counts.entrySet().stream()
                .sorted(Map.Entry
                        .<String, Integer>comparingByValue()
                        .reversed())
                .limit(MAX_TERMS)
                .map(Map.Entry::getKey)
                .reduce((a, b) -> a + " " + b)
                .orElse("");
    }
}