package processing;

import java.util.ArrayList;
import java.util.List;

public class NGramGenerator {

    public static List<String> generateNGrams(List<String> words, int n) {

        List<String> ngrams = new ArrayList<>();

        for (int i = 0; i <= words.size() - n; i++) {

            StringBuilder ngram = new StringBuilder();

            for (int j = 0; j < n; j++) {

                ngram.append(words.get(i + j));

                if (j < n - 1) {
                    ngram.append(" ");
                }
            }

            ngrams.add(ngram.toString());
        }

        return ngrams;
    }
}