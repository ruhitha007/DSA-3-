package processing;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class PDFTextExtractor {

    public static String extractText(String filePath)
            throws IOException {
                java.util.logging.Logger
        .getLogger("org.apache.pdfbox")
        .setLevel(java.util.logging.Level.SEVERE);

        File file = new File(filePath);

        /*
         * Small safety guard: a missing or empty file
         * yields no text. Problematic downloads are
         * handled per-candidate and never hang.
         */
        if (!file.exists()
                || file.length() == 0) {

            return "";
        }

        try (PDDocument document = Loader.loadPDF(file)) {

            PDFTextStripper stripper =
                    new PDFTextStripper();

            return stripper.getText(document);
        }
    }
}