package processing;

import java.util.ArrayList;
import java.util.List;

public class TextProcessor {

    public static List<String> tokenize(String text) {

        text = text.toLowerCase();

        text = text.replaceAll("[^a-z0-9\\s]", "");

        String[] words = text.split("\\s+");

        List<String> tokens = new ArrayList<>();

        for (String word : words) {
            if (!word.isEmpty()) {
                tokens.add(word);
            }
        }

        return tokens;
    }
}