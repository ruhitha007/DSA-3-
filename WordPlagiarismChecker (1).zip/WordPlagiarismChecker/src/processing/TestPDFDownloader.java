package processing;

public class TestPDFDownloader {

    public static void main(String[] args) {

        String pdfUrl =
                "https://www.mdpi.com/2078-2489/11/4/193/pdf?version=1587379966";

        String outputPath =
                "source.pdf";

        try {

            boolean success =
                    PDFDownloader.downloadPDF(
                            pdfUrl,
                            outputPath
                    );

            if (success) {

                System.out.println(
                        "Source paper downloaded successfully."
                );

            } else {

                System.out.println(
                        "Source paper download failed."
                );
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}