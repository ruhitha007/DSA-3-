package plagiarism;

import dsa.AlgorithmStats;
import dsa.KMP;
import dsa.RabinKarp;
import java.util.ArrayList;
import java.util.List;
import model.DSAComparisonResult;
import model.MatchResult;
import model.PlagiarismResult;
import processing.NGramGenerator;
import processing.TextProcessor;

public class PlagiarismEngine {

    private DocumentIndexer indexer;
    private int n;

    // Stores the actual source document text
    // so KMP and Rabin-Karp can search it.
    private String sourceText;

    // Stores the latest DSA comparison result
    private DSAComparisonResult dsaResult;


    public PlagiarismEngine(int tableSize, int n) {

        this.indexer = new DocumentIndexer(tableSize);
        this.n = n;
    }


    /**
     * Indexes the source document.
     */
    public void addSourceDocument(String sourceText) {

        // Store source text for DSA comparison
        this.sourceText = sourceText;

        // Existing indexing logic
        indexer.indexDocument(sourceText, n);
    }


    /**
     * Analyzes the user's document against
     * the indexed source document.
     */
    public PlagiarismResult analyze(String userText) {

        List<String> userWords =
                TextProcessor.tokenize(userText);

        List<String> userNGrams =
                NGramGenerator.generateNGrams(
                        userWords,
                        n
                );

        boolean[] matchedPositions =
                new boolean[userWords.size()];

        List<MatchResult> matches =
                new ArrayList<>();


        /*
         * ========================================
         * EXISTING PLAGIARISM DETECTION
         * ========================================
         *
         * HashTable + n-gram matching.
         *
         * This remains the main plagiarism
         * detection mechanism.
         */

        for (int i = 0;
             i < userNGrams.size();
             i++) {

            String ngram =
                    userNGrams.get(i);

            List<Integer> sourcePositions =
                    indexer.search(ngram);

            if (!sourcePositions.isEmpty()) {

                int sourcePosition =
                        sourcePositions.get(0);


                /*
                 * Mark the n-gram words as matched.
                 */
                for (int j = 0;
                     j < n;
                     j++) {

                    if (i + j <
                            matchedPositions.length) {

                        matchedPositions[i + j] = true;
                    }
                }


                MatchResult match =
                        new MatchResult(
                                ngram,
                                i,
                                sourcePosition,
                                100.0
                        );

                matches.add(match);
            }
        }


        /*
         * ========================================
         * COUNT MATCHED WORDS
         * ========================================
         */

        int matchedWords = 0;

        for (boolean matched :
                matchedPositions) {

            if (matched) {
                matchedWords++;
            }
        }


        int totalWords =
                userWords.size();


        /*
         * ========================================
         * CALCULATE SIMILARITY
         * ========================================
         */

        double similarity = 0.0;

        if (totalWords > 0) {

            similarity =
                    ((double) matchedWords
                            / totalWords)
                            * 100;
        }


        /*
         * ========================================
         * DSA COMPARISON
         * ========================================
         *
         * Run KMP and Rabin-Karp separately.
         *
         * IMPORTANT:
         * This does NOT replace the plagiarism
         * calculation above.
         *
         * The results are now stored so that
         * DashboardServer can send them to React.
         */

        dsaResult =
                runDSAComparison(userNGrams);


        /*
         * ========================================
         * RETURN PLAGIARISM RESULT
         * ========================================
         */

        return new PlagiarismResult(
                totalWords,
                matchedWords,
                similarity,
                matches
        );
    }


    /**
     * Returns the latest DSA comparison result.
     */
    public DSAComparisonResult getDSAResult() {

        return dsaResult;
    }


    /**
     * Runs KMP and Rabin-Karp against the
     * actual source document.
     */
    private DSAComparisonResult runDSAComparison(
            List<String> userNGrams) {


        /*
         * ========================================
         * CHECK SOURCE DOCUMENT
         * ========================================
         */

        if (sourceText == null
                || sourceText.isBlank()) {

            System.out.println(
                    "\n========================================"
            );

            System.out.println(
                    "DSA ALGORITHM COMPARISON"
            );

            System.out.println(
                    "========================================"
            );

            System.out.println(
                    "Source text unavailable."
            );

            return null;
        }


        /*
         * ========================================
         * STATISTICS
         * ========================================
         */

        long totalKMPComparisons = 0;

        long totalKMPTime = 0;

        long totalRabinCharacterComparisons = 0;

        long totalRabinHashComparisons = 0;

        long totalRabinTime = 0;

        int kmpMatches = 0;

        int rabinMatches = 0;


        /*
         * ========================================
         * RUN BOTH ALGORITHMS
         * ========================================
         */

        for (String ngram :
                userNGrams) {


            /*
             * ------------------------------------
             * KMP
             * ------------------------------------
             */

            AlgorithmStats kmpStats =
                    KMP.searchWithStats(
                            sourceText,
                            ngram
                    );

            totalKMPComparisons +=
                    kmpStats.getComparisons();

            totalKMPTime +=
                    kmpStats.getExecutionTime();

            if (kmpStats.getMatchPosition()
                    != -1) {

                kmpMatches++;
            }


            /*
             * ------------------------------------
             * RABIN-KARP
             * ------------------------------------
             */

            AlgorithmStats rabinStats =
                    RabinKarp.searchWithStats(
                            sourceText,
                            ngram
                    );

            totalRabinCharacterComparisons +=
                    rabinStats.getComparisons();

            totalRabinHashComparisons +=
                    rabinStats.getHashComparisons();

            totalRabinTime +=
                    rabinStats.getExecutionTime();

            if (rabinStats.getMatchPosition()
                    != -1) {

                rabinMatches++;
            }
        }


        /*
         * ========================================
         * CONVERT TIME
         * ========================================
         */

        double kmpTimeMs =
                totalKMPTime / 1_000_000.0;

        double rabinTimeMs =
                totalRabinTime / 1_000_000.0;


        /*
         * ========================================
         * OBSERVATION
         * ========================================
         */

        String observation;

        if (kmpTimeMs < rabinTimeMs) {

            observation =
                    "KMP was faster for this test case.";

        } else if (rabinTimeMs < kmpTimeMs) {

            observation =
                    "Rabin-Karp was faster for this test case.";

        } else {

            observation =
                    "Both algorithms had similar execution time.";
        }


        /*
         * ========================================
         * DISPLAY DSA COMPARISON
         * ========================================
         *
         * We KEEP this terminal output because
         * it is useful for testing and viva/demo.
         */

        System.out.println(
                "\n========================================"
        );

        System.out.println(
                "DSA ALGORITHM COMPARISON"
        );

        System.out.println(
                "========================================"
        );


        /*
         * KMP RESULTS
         */

        System.out.println(
                "\nKMP"
        );

        System.out.println(
                "----------------------------------------"
        );

        System.out.println(
                "Matches Found: "
                        + kmpMatches
        );

        System.out.println(
                "Character Comparisons: "
                        + totalKMPComparisons
        );

        System.out.println(
                "Execution Time: "
                        + kmpTimeMs
                        + " ms"
        );


        /*
         * RABIN-KARP RESULTS
         */

        System.out.println(
                "\nRABIN-KARP"
        );

        System.out.println(
                "----------------------------------------"
        );

        System.out.println(
                "Matches Found: "
                        + rabinMatches
        );

        System.out.println(
                "Hash Comparisons: "
                        + totalRabinHashComparisons
        );

        System.out.println(
                "Character Comparisons: "
                        + totalRabinCharacterComparisons
        );

        System.out.println(
                "Execution Time: "
                        + rabinTimeMs
                        + " ms"
        );


        /*
         * PERFORMANCE COMPARISON
         */

        System.out.println(
                "\n========================================"
        );

        System.out.println(
                "PERFORMANCE COMPARISON"
        );

        System.out.println(
                "========================================"
        );

        System.out.println(
                "KMP Time: "
                        + kmpTimeMs
                        + " ms"
        );

        System.out.println(
                "Rabin-Karp Time: "
                        + rabinTimeMs
                        + " ms"
        );

        System.out.println(
                "KMP Comparisons: "
                        + totalKMPComparisons
        );

        System.out.println(
                "Rabin-Karp Character Comparisons: "
                        + totalRabinCharacterComparisons
        );

        System.out.println(
                "Rabin-Karp Hash Comparisons: "
                        + totalRabinHashComparisons
        );

        System.out.println(
                "\nObservation: "
                        + observation
        );


        /*
         * ========================================
         * CREATE RESULT OBJECT
         * ========================================
         */

        return new DSAComparisonResult(

                kmpMatches,
                totalKMPComparisons,
                kmpTimeMs,

                rabinMatches,
                totalRabinHashComparisons,
                totalRabinCharacterComparisons,
                rabinTimeMs,

                observation
        );
    }
}