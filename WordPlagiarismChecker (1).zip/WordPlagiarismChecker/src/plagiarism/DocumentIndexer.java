package plagiarism;

import dsa.HashTable;
import java.util.List;
import processing.NGramGenerator;
import processing.TextProcessor;

public class DocumentIndexer {

    private HashTable hashTable;

    public DocumentIndexer(int tableSize) {
        hashTable = new HashTable(tableSize);
    }

    public void indexDocument(String text, int n) {

        // Step 1: Convert text into words
        List<String> words = TextProcessor.tokenize(text);

        // Step 2: Generate n-grams
        List<String> ngrams =
                NGramGenerator.generateNGrams(words, n);

        // Step 3: Store each n-gram in Hash Table
        for (int i = 0; i < ngrams.size(); i++) {

            hashTable.insert(ngrams.get(i), i);
        }
    }

    public List<Integer> search(String ngram) {

    return hashTable.search(ngram);
}
}