package plagiarism;

import processing.NGramGenerator;
import processing.TextProcessor;

import java.util.List;

public class MatchDetector {

    private DocumentIndexer indexer;

    public MatchDetector(DocumentIndexer indexer) {
        this.indexer = indexer;
    }

    public int findMatches(String userText, int n) {

        List<String> words = TextProcessor.tokenize(userText);

        List<String> ngrams =
                NGramGenerator.generateNGrams(words, n);

        boolean[] matchedPositions = new boolean[words.size()];

        System.out.println("Matching n-grams:");

        for (int i = 0; i < ngrams.size(); i++) {

            String ngram = ngrams.get(i);

            List<Integer> positions = indexer.search(ngram);

if (!positions.isEmpty()) {

    System.out.println(
            "\"" + ngram + "\"" +
            " → Reference positions: " + positions
    );

    for (int j = 0; j < n; j++) {
        matchedPositions[i + j] = true;
    }
}
        }

        int matchedWords = 0;

        for (boolean matched : matchedPositions) {

            if (matched) {
                matchedWords++;
            }
        }

        return matchedWords;
    }
}