package plagiarism;

import model.PlagiarismResult;

import java.util.ArrayList;
import java.util.List;

public class MultiSourceAnalyzer {

    private List<String> sourceTexts;

    public MultiSourceAnalyzer() {
        sourceTexts = new ArrayList<>();
    }

    public void addSource(String sourceText) {
        sourceTexts.add(sourceText);
    }

    public void analyze(String userText) {

        System.out.println("\n================================");
        System.out.println("PLAGIARISM ANALYSIS");
        System.out.println("================================");

        for (int i = 0; i < sourceTexts.size(); i++) {

            PlagiarismEngine engine =
                    new PlagiarismEngine(100, 3);

            engine.addSourceDocument(sourceTexts.get(i));

            PlagiarismResult result =
                    engine.analyze(userText);

            System.out.printf(
                    "\nSource %d%n",
                    i + 1
            );

            System.out.printf(
                    "Similarity: %.2f%%%n",
                    result.getSimilarity()
            );

            System.out.println(
                    "Matched words: "
                    + result.getMatchedWords()
            );
        }
    }
}